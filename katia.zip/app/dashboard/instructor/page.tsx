import InstructorDashboard from "../../../components/pages/instructor-dashboard"

export default function InstructorDashboardPage() {
  return <InstructorDashboard />
}
