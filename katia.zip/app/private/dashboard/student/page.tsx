import StudentDashboard from "@/components/pages/dashboard/student-dashboard"

export default function StudentDashboardPage() {
  return <StudentDashboard />
}
