import InstructorDashboard from "@/components/pages/dashboard/instructor-dashboard"

export default function InstructorDashboardPage() {
  return <InstructorDashboard />
}
