import AdminDashboard from "@/components/pages/dashboard/admin-dashboard"

export default function AdminPage() {
  return <AdminDashboard />
}
