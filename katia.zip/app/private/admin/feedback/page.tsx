import AdminFeedbackPage from "@/components/pages/admin/admin-feedback-page"

export default function FeedbackManagement() {
  return <AdminFeedbackPage />
}
