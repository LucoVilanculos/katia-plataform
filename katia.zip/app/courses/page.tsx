import CoursesPage from "@/components/pages/courses-page"

export default function Courses() {
  return <CoursesPage />
}
