import StudentDashboard from "../../../components/pages/student-dashboard"

export default function StudentDashboardPage() {
  return <StudentDashboard />
}
