import AboutPage from "../../components/pages/about-page"

export default function About() {
  return <AboutPage />
}
