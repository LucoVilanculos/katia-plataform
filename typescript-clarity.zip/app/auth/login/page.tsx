import LoginPage from "@/components/pages/auth/login-page"

export default function Login() {
  return <LoginPage />
}
