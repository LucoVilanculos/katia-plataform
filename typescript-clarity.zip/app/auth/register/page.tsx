import RegisterPage from "@/components/pages/auth/register-page"

export default function Register() {
  return <RegisterPage />
}
