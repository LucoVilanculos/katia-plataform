import AdminSecurityPage from "@/components/pages/admin/admin-security-page"

export default function SecurityManagement() {
  return <AdminSecurityPage />
}
