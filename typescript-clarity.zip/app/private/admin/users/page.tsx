import AdminUsersPage from "@/components/pages/admin/admin-users-page"

export default function UsersManagement() {
  return <AdminUsersPage />
}
